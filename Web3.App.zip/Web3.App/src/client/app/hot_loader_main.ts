// Hot loading is temporary disabled
//
// import { HashLocationStrategy, HashLocationStrategy } from '@angular/common';
// import { provide } from '@angular/core';
// import { ROUTER_PROVIDERS } from '@angular/router';
// import { AppComponent } from './app.component';

// System.import('//localhost:<%= HOT_LOADER_PORT %>/ng2-hot-loader')
//   .then(loader => {
//     loader.ng2HotLoaderBootstrap(AppComponent, [
//       ROUTER_PROVIDERS,
//       provide(LocationStrategy, { useClass: HashLocationStrategy })
//     ]);
//   });
