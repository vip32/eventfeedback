export { EventComponent } from './event.component';
