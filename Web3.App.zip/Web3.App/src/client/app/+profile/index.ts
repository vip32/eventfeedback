export { ProfileComponent } from './profile.component';
